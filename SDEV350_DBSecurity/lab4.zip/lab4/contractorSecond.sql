alter session set current_schema = lab4;
INSERT INTO proposals2017 (task, proposal) VALUES ('dig','350');
INSERT INTO proposals2018 (task, proposal) VALUES ('paint','570');
SELECT * FROM bidrates2017;
SELECT * FROM proposals2017;
